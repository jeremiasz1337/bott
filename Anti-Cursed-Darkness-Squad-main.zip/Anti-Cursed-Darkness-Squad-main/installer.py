import os
import sys


os.system('sudo apt update')
os.system('apt install git')
os.system('sudo apt install nodejs')
os.system('sudo apt install npm')
os.system('sudo npm install cloudflare-bypasser')
os.system('sudo npm install crypto-random-string')
os.system('sudo npm install random-string')
os.system('sudo npm install random-useragent')
os.system('sudo npm install fs')
os.system('sudo npm install url')
os.system('sudo npm install net')
os.system('sudo npm install eval')
os.system('sudo npm install cloudscraper')
os.system('npm install')
os.system('sudo apt install python3')
os.system('sudo apt install python3-pip')
os.system('sudo pip3 install -r requirements.txt')
os.system('sudo apt install python-minimal')
os.system('sudo apt install perl')
os.system('chmod +x darkness')
os.system('sudo ./darkness')


