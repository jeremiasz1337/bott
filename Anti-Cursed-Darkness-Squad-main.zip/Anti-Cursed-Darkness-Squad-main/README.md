![GitHub Logo](https://raw.githubusercontent.com/Z3NTL3/Anti-Cursed-Darkness-Squad-BETA/main/putty.png)<br>
# Anti-Cursed-Darkness-Squad v7
Powerful Layer 7 & 4 panel. 
 
Thanks to MHProDev, Leeon123, R00tS3c, emp001, cocorisss  and wachirachoomsiri for their methods. This tool is an one-in-all DDOS Panel with the best methods. Only the panel it self, functionality, the proxy-crawler is coded by z3ntl3 root. Others are not part of our code!
 
<p> NOTICE: When proxies banned, then renew it by "proxy-crawl" command.</p>
<br><p>We are not responsable for what u do with this tool.

# Proofs
<p> Cracked.to Downed: https://vimeo.com/574405317</p>
<p> Zap Hosting Downed: https://www.youtube.com/watch?v=66gz6YlZDws</p>
<p> Rip Stresser Downed: https://www.youtube.com/watch?v=ydAghgWiS2I </p>
<p> iWantCheats.net Downed: https://www.youtube.com/watch?v=KWBv-ot9weE</p>
<p> NoviHacks.com Downed: https://www.youtube.com/watch?v=uda7CWAWQlU</p>
<p> WallHax.com Downed: https://www.youtube.com/watch?v=GSK_YLIsfpU</p>
<p> Hetzner GmbH Server Downed: https://www.youtube.com/watch?v=qzBAXuP7f9I&lc=UgxOhjlE0eg5iyksQ4V4AaABAg
<p> Atom Stresser Downed: https://www.youtube.com/watch?v=UyQ_hEFnsBg</p>
<p> Dos Ninja Stresser Downed: https://www.youtube.com/watch?v=_BPUP68Xqag</p>
<p> Spy Hackerz Downed: https://www.youtube.com/watch?v=YsrAGwlnM4U</p>
<p> Turk Hack Team Downed: https://www.youtube.com/watch?v=pqlYKMa0Q5I</p>

# Methods
![image](https://user-images.githubusercontent.com/48758770/125307020-fba82180-e32f-11eb-84a9-60cd852aacc1.png)
<br><br>
Thanks to MHProDev, Leeon123, R00tS3c, emp001, cocorisss  and wachirachoomsiri for their methods. This tool is an one-in-all DDOS Panel with the best methods. Only the panel it self, and the functionality is coded by z3ntl3 root. Others are not part of our code!


# Installation

    Go into your Anti-Cursed-Darkness-Squad Installation Folder
    Or install it by:
    
    git clone https://github.com/Z3NTL3/Anti-Cursed-Darkness-Squad-BETA
    cd Anti-Cursed-Darkness-Squad-BETA
   
    
    ulimit -n 999999
    sudo apt install python3
    python3 installer.py
 
    ERROR FIX:
    chmod +x fixer
    sudo ./fixer
    
    
    To run after installation:
    ulimit -n 999999
    sudo ./darkness
    
    When proxies banned, then renew it by "proxy-crawl" command.
    
    We recommend using 16gb ram , 1-10 GBPS machine to have the good power! 


# Updates
https://scorpion-hackz.com/acds/update-log.txt
